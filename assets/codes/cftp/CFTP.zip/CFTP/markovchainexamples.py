# -*- coding: utf-8 -*-
"""
Some examples of simple Markov chains and their forward and backward
time evolution.

@author: Eli
"""

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

num_states = 10            
    
# The random function f(x,r) used by the Markov chain to evolve
# in time. x_t = f(x_{t-1}, r), where x_t is the state at time
# t and r is a set of random numbers.
def markovchain_function(state, random_variable):
    if random_variable < 0.45:
        return np.minimum(state+1, num_states-1)
    elif random_variable < 0.46:
        return state
    else:
        return np.maximum(state-1, 0)
        
# Perform forward time evolution on multiple markov chains.
num_time_steps = 100
num_chains     = num_states//2
times          = np.arange(num_time_steps)        
states         = np.zeros((num_chains, num_time_steps))
states[:,0]    = np.arange(0, num_states, 2)

# Each chain has its own set of random numbers.
random_variables = np.random.rand(num_chains, num_time_steps)

for chain in range(num_chains):
    for time in range(1,num_time_steps):
        states[chain, time] = markovchain_function(states[chain, time-1], random_variables[chain, time])

# Plot the results.        
for chain in range(num_chains):
    plt.plot(times, states[chain,:], '-')
plt.ylabel('state')
plt.xlabel('time')        

plt.savefig('markovchainsexamples.png', dpi=200)

# Each chain has the same set of random numbers.
random_variables = np.random.rand(num_chains, num_time_steps)

for chain in range(num_chains):
    for time in range(1,num_time_steps):
        states[chain, time] = markovchain_function(states[chain, time-1], random_variables[0, time])

# Plot the results.      
plt.figure()
for chain in range(num_chains):
    plt.plot(times, states[chain,:], '-')
plt.ylabel('state')
plt.xlabel('time')        

plt.savefig('markovchains_coallescence_examples.png', dpi=200)
        
plt.show()