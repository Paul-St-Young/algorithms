# -*- coding: utf-8 -*-
"""
Demonstration of how Markov chains converge.

@author: Eli
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rc('font', size=26)
matplotlib.rc('lines', linewidth=3)
matplotlib.rcParams['lines.markersize'] = 10 
matplotlib.rcParams['figure.figsize']   = (16,12)

np.random.seed(42)

L = 20
x = np.arange(L)

desired_prob = np.abs(np.cos(4.0*x/L))*x
desired_prob /= np.sum(desired_prob)

def metropolis_mc_move(x):
    r1 = np.random.rand()
    r2 = np.random.rand()
    
    # Propose a move to the left or right at random.
    if r1 < 0.5:
        new_x = (x-1+L) % L
    else:
        new_x = (x+1+L) % L
        
    acceptance_prob = desired_prob[new_x]/desired_prob[x]
    
    if r2 < acceptance_prob:
        return new_x
    else:
        return x
    
def metropolis_mcmc(num_samples, num_time_steps_per_sample, burn_in=1000):
    x = np.random.randint(L)
    
    for time in range(burn_in):
        x = metropolis_mc_move(x)
        
    samples = np.zeros(num_samples, dtype=int)
    for sample in range(num_samples):
        for time in range(num_time_steps_per_sample):
            x = metropolis_mc_move(x)    
        samples[sample] = x
        
    return samples

num_samples   = L*1000
sweep_sizes   = [2,32,256,2048]
samples_hists = []
for sweep_size in sweep_sizes:
    samples = metropolis_mcmc(num_samples, sweep_size)
    
    samples_hist = np.zeros(L)
    for sample in range(num_samples):
        samples_hist[samples[sample]] += 1.0/num_samples
        
    samples_hists.append(samples_hist)
    
plt.figure()
plt.plot(x, desired_prob, 'k--', label='Target $P(x)$')
ind_sweep = 0
for sweep_size in sweep_sizes:
    plt.errorbar(x, samples_hists[ind_sweep], yerr=np.sqrt(samples_hists[ind_sweep]/num_samples), label='$T=${}'.format(sweep_size))
    ind_sweep += 1
    
plt.legend()
plt.xlabel('$x$')
plt.ylabel('Frequency')


plt.savefig('markovchain_convergence_histograms.png', dpi=200)

plt.show()